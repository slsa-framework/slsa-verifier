// See https://github.com/bazel-contrib/rules_go/blob/7f6a9bf5870f2b5ffbba1615658676dcabf9edc7/docs/go/core/bzlmod.md#depending-on-tools
//go:build tools
// +build tools

package linting_tools

import (
    _ "github.com/google/keep-sorted"
)
