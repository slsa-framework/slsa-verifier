// Ignored by https://github.com/aspect-build/rules_lint/blob/example/.gitattributes
export var x = "white space issue and no semi colon";
