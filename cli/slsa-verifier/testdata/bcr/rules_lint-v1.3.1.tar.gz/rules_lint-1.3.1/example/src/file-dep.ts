export class Greeter {
  greet(name: string) {
    return `Hello, ${name}`;
  }
}
