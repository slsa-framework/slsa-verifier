#ifndef MAIN_HELLO_GREET_H_
#define MAIN_HELLO_GREET_H_

// deliberately missing #include <string> to provoke error
std::string get_greet(const std::string &thing);

#endif
