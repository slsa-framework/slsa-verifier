import java.util.*
import javax.security.*

fun main() {
  println("Hello, world!")
}
