#include "hello-greet-with-error.h"

std::string get_greet(const std::string& who) { return "Hello " + who; }
